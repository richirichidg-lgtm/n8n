export const OUTPUT_FORMAT = `
## Output Format
Return ONLY the complete updated parameters object that matches the node's parameter structure. Include ALL parameters, both modified and unmodified.`;
