export const MAX_AI_BUILDER_PROMPT_LENGTH = 1000; // characters

export const DEFAULT_AUTO_COMPACT_THRESHOLD_TOKENS = 20_000; // Tokens threshold for auto-compacting the conversation
